# Phúc An Demo Website

Trang web mẫu giống với giao diện của Phúc An Solutions, được xây dựng bằng Next.js và Tailwind CSS.

## Chạy local:
```bash
npm install
npm run dev
```
